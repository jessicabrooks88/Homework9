function setup() {
  createCanvas(300, 500);
}

function draw() {
  background(250, 0, 0);
  circle(150,150,70);
  square(107,200,90);
  rect(200,200,30,60);
  rect(73,200,30,56);
  triangle(111, 130, 150, 90, 190, 130);
  textSize(45);
    text('Here I Am', 55, 70);
   textSize(32);
    text('Jessica Brooks', 50, 400);
}